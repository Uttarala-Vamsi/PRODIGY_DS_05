# PRODIGY_DS_05-Intern-Pinaki-Jupyter-Lab-TASK-05
As an Intern, I have created and completed in 12-14 days in Jupyter Lab as per the task of Prodigy InfoTech i.e., DATA SCIENCE ----TASK 5.
Task : Analyze traffic accident data to identify patterns related to road conditions, weather, and time of day. Visualize accident hotspots and contributing factors.



https://github.com/PINAKIMATHAN/PRODIGY_DS_05-Intern-Pinaki-Jupyter-Lab-TASK-05/assets/107812574/e77c3201-e80b-4a3d-9315-2bbf8fc34656

